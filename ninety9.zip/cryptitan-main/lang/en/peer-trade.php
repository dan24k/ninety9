<?php

return [
    'not_found'   => 'Trade could not be found.',
    'description' => 'Peer Trade (:id)',
];