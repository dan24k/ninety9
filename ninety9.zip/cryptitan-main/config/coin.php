<?php

return [
    'mock_token' => (bool) env('COIN_MOCK_TOKEN', false),
];
